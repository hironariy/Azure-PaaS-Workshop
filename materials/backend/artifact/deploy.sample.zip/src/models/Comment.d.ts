/**
 * Comment Model
 * Mongoose schema for post comments
 * Reference: /design/DatabaseDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
import mongoose, { Document, Types } from 'mongoose';
export interface IComment extends Document {
    post: Types.ObjectId;
    author: Types.ObjectId;
    content: string;
    parentComment?: Types.ObjectId;
    isEdited: boolean;
    isDeleted: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Comment: mongoose.Model<IComment, {}, {}, {}, mongoose.Document<unknown, {}, IComment, {}, {}> & IComment & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
//# sourceMappingURL=Comment.d.ts.map