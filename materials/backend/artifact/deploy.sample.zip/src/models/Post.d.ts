/**
 * Post Model
 * Mongoose schema for blog posts
 * Reference: /design/DatabaseDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
import mongoose, { Document, Types } from 'mongoose';
export interface IPost extends Document {
    title: string;
    slug: string;
    content: string;
    excerpt?: string;
    author: Types.ObjectId;
    status: 'draft' | 'published' | 'archived';
    tags: string[];
    featuredImageUrl?: string;
    viewCount: number;
    publishedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}
/**
 * Generate slug from title
 */
export declare function generateSlug(title: string): string;
export declare const Post: mongoose.Model<IPost, {}, {}, {}, mongoose.Document<unknown, {}, IPost, {}, {}> & IPost & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
//# sourceMappingURL=Post.d.ts.map