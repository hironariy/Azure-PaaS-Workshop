/**
 * Express Application Configuration
 * Main application entry point
 * Reference: /design/BackendApplicationDesign.md
 *
 * PaaS Changes from IaaS:
 * - Default port changed from 3000 to 8080 (App Service default)
 * - Rest of the code is identical to IaaS
 */
import { Application } from 'express';
/**
 * Create and configure Express application
 */
export declare function createApp(): Application;
export default createApp;
//# sourceMappingURL=app.d.ts.map