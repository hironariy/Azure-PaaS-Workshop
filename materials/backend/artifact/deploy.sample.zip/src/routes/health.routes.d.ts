/**
 * Health Check Routes
 * Provides endpoints for App Service health probes
 * Reference: /design/BackendApplicationDesign.md
 *
 * PaaS Notes:
 * - /health is used by App Service health probe
 * - Same code as IaaS, works with Azure Load Balancer
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=health.routes.d.ts.map