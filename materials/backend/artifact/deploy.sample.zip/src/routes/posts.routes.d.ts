/**
 * Posts Routes
 * CRUD operations for blog posts
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=posts.routes.d.ts.map