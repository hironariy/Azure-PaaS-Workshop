/**
 * Comments Routes
 * Comment management for blog posts
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=comments.routes.d.ts.map