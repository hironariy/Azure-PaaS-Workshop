"use strict";
/**
 * Health Check Routes
 * Provides endpoints for App Service health probes
 * Reference: /design/BackendApplicationDesign.md
 *
 * PaaS Notes:
 * - /health is used by App Service health probe
 * - Same code as IaaS, works with Azure Load Balancer
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const database_1 = require("../config/database");
const router = (0, express_1.Router)();
/**
 * GET /health
 * Simple health check for App Service health probes
 * Returns 200 if healthy, 503 if unhealthy
 */
router.get('/health', (_req, res) => {
    const dbConnected = (0, database_1.isDatabaseConnected)();
    if (dbConnected) {
        res.status(200).json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
        });
    }
    else {
        res.status(503).json({
            status: 'unhealthy',
            reason: 'Database not connected',
            timestamp: new Date().toISOString(),
        });
    }
});
/**
 * GET /health/detailed
 * Detailed health check with component statuses
 * For monitoring and debugging (not for health probes)
 */
router.get('/health/detailed', (_req, res) => {
    const dbState = (0, database_1.getDatabaseState)();
    const dbHealthy = dbState === 'connected';
    const healthStatus = {
        status: dbHealthy ? 'healthy' : 'degraded',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        components: {
            database: {
                status: dbHealthy ? 'healthy' : 'unhealthy',
                state: dbState,
            },
            api: {
                status: 'healthy',
            },
        },
        memory: {
            heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
            heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
            rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
        },
    };
    res.status(dbHealthy ? 200 : 503).json(healthStatus);
});
/**
 * GET /ready
 * Readiness check for App Service
 */
router.get('/ready', (_req, res) => {
    const dbConnected = (0, database_1.isDatabaseConnected)();
    if (dbConnected) {
        res.status(200).json({ ready: true });
    }
    else {
        res.status(503).json({ ready: false, reason: 'Database not ready' });
    }
});
/**
 * GET /live
 * Liveness check - always returns 200 if the process is running
 */
router.get('/live', (_req, res) => {
    res.status(200).json({ live: true });
});
exports.default = router;
//# sourceMappingURL=health.routes.js.map