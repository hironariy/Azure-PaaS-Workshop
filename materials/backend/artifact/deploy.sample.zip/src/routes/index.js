"use strict";
/**
 * Routes Index
 * Central route configuration
 *
 * No PaaS changes - identical to IaaS
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const health_routes_1 = __importDefault(require("./health.routes"));
const posts_routes_1 = __importDefault(require("./posts.routes"));
const users_routes_1 = __importDefault(require("./users.routes"));
const comments_routes_1 = __importDefault(require("./comments.routes"));
const router = (0, express_1.Router)();
// Health check routes (no /api prefix - for direct App Service access)
router.use('/', health_routes_1.default);
// Health check also at /api/health for SWA Linked Backend routing
// SWA proxies /api/* to the backend, so /api/health is needed
router.use('/api', health_routes_1.default);
// API routes
router.use('/api/posts', posts_routes_1.default);
router.use('/api/users', users_routes_1.default);
router.use('/api', comments_routes_1.default); // Comments have mixed paths
exports.default = router;
//# sourceMappingURL=index.js.map