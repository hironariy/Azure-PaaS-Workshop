"use strict";
/**
 * Users Routes
 * User profile management
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const auth_middleware_1 = require("../middleware/auth.middleware");
const error_middleware_1 = require("../middleware/error.middleware");
const models_1 = require("../models");
const logger_1 = require("../utils/logger");
const sanitize_1 = require("../utils/sanitize");
const router = (0, express_1.Router)();
/**
 * Validation error handler
 */
function handleValidation(req, _res, next) {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        next(error_middleware_1.ApiError.badRequest('Validation failed', { errors: errors.array() }));
        return;
    }
    next();
}
/**
 * GET /api/users/me
 * Get current authenticated user's profile
 */
router.get('/me', auth_middleware_1.authenticate, async (req, res, next) => {
    try {
        const existingUser = await models_1.User.findOne({ oid: req.user.oid }).lean();
        if (!existingUser) {
            // First-time user - create profile from token info
            const newUser = await models_1.User.create({
                oid: req.user.oid,
                email: req.user.email,
                displayName: (0, sanitize_1.sanitizePlain)(req.user.name),
                username: req.user.email.split('@')[0].toLowerCase().replace(/[^a-z0-9_-]/g, ''),
                lastLoginAt: new Date(),
            });
            logger_1.logger.info('New user created:', { oid: req.user.oid, email: (0, logger_1.sanitizeEmail)(req.user.email) });
            res.json(newUser.toObject());
            return;
        }
        // Update last login
        await models_1.User.updateOne({ oid: req.user.oid }, { lastLoginAt: new Date() });
        res.json(existingUser);
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/users/:username
 * Get user by username (public profile)
 */
router.get('/:username', [(0, express_validator_1.param)('username').isString().trim().isLength({ min: 3, max: 30 })], handleValidation, async (req, res, next) => {
    try {
        const user = await models_1.User.findOne({
            username: req.params.username,
            isActive: true,
        })
            .select('displayName username bio avatarUrl createdAt')
            .lean();
        if (!user) {
            next(error_middleware_1.ApiError.notFound('User'));
            return;
        }
        res.json(user);
    }
    catch (error) {
        next(error);
    }
});
/**
 * PUT /api/users/me
 * Update current user's profile
 */
router.put('/me', auth_middleware_1.authenticate, [
    (0, express_validator_1.body)('displayName').optional().isString().trim().isLength({ min: 1, max: 100 }),
    (0, express_validator_1.body)('bio').optional().isString().trim().isLength({ max: 500 }),
    (0, express_validator_1.body)('avatarUrl').optional().isURL(),
], handleValidation, async (req, res, next) => {
    try {
        const updates = {};
        if (req.body.displayName)
            updates.displayName = (0, sanitize_1.sanitizePlain)(req.body.displayName);
        if (req.body.bio !== undefined)
            updates.bio = (0, sanitize_1.sanitizePlain)(req.body.bio);
        if (req.body.avatarUrl !== undefined)
            updates.avatarUrl = req.body.avatarUrl;
        const user = await models_1.User.findOneAndUpdate({ oid: req.user.oid }, { $set: updates }, { new: true, runValidators: true }).lean();
        if (!user) {
            next(error_middleware_1.ApiError.notFound('User'));
            return;
        }
        logger_1.logger.info('User profile updated:', { oid: req.user.oid });
        res.json(user);
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=users.routes.js.map