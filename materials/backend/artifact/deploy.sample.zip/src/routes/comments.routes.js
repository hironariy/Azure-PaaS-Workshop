"use strict";
/**
 * Comments Routes
 * Comment management for blog posts
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const auth_middleware_1 = require("../middleware/auth.middleware");
const error_middleware_1 = require("../middleware/error.middleware");
const models_1 = require("../models");
const logger_1 = require("../utils/logger");
const sanitize_1 = require("../utils/sanitize");
const router = (0, express_1.Router)();
/**
 * Validation error handler
 */
function handleValidation(req, _res, next) {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        next(error_middleware_1.ApiError.badRequest('Validation failed', { errors: errors.array() }));
        return;
    }
    next();
}
/**
 * GET /api/posts/:slug/comments
 * Get comments for a post
 */
router.get('/posts/:slug/comments', auth_middleware_1.optionalAuthenticate, [
    (0, express_validator_1.param)('slug').isString().trim(),
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).toInt(),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 50 }).toInt(),
], handleValidation, async (req, res, next) => {
    try {
        const page = req.query.page || 1;
        const limit = req.query.limit || 20;
        const skip = (page - 1) * limit;
        // Find the post
        const post = await models_1.Post.findOne({ slug: req.params.slug, status: 'published' });
        if (!post) {
            next(error_middleware_1.ApiError.notFound('Post'));
            return;
        }
        // Get comments
        const [comments, total] = await Promise.all([
            models_1.Comment.find({ post: post._id, isDeleted: false, parentComment: null })
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .populate('author', 'displayName username avatarUrl')
                .lean(),
            models_1.Comment.countDocuments({ post: post._id, isDeleted: false, parentComment: null }),
        ]);
        res.json({
            comments,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/posts/:slug/comments
 * Add a comment to a post (authenticated)
 */
router.post('/posts/:slug/comments', auth_middleware_1.authenticate, [
    (0, express_validator_1.param)('slug').isString().trim(),
    (0, express_validator_1.body)('content').isString().trim().isLength({ min: 1, max: 2000 }),
    (0, express_validator_1.body)('parentCommentId').optional().isMongoId(),
], handleValidation, async (req, res, next) => {
    try {
        // Find the post
        const post = await models_1.Post.findOne({ slug: req.params.slug, status: 'published' });
        if (!post) {
            next(error_middleware_1.ApiError.notFound('Post'));
            return;
        }
        // Find or create user
        let user = await models_1.User.findOne({ oid: req.user.oid });
        if (!user) {
            user = await models_1.User.create({
                oid: req.user.oid,
                email: req.user.email,
                displayName: req.user.name,
                username: req.user.email.split('@')[0].toLowerCase().replace(/[^a-z0-9_-]/g, ''),
            });
        }
        // Validate parent comment if provided
        if (req.body.parentCommentId) {
            const parentComment = await models_1.Comment.findOne({
                _id: req.body.parentCommentId,
                post: post._id,
                isDeleted: false,
            });
            if (!parentComment) {
                next(error_middleware_1.ApiError.notFound('Parent comment'));
                return;
            }
        }
        const comment = await models_1.Comment.create({
            post: post._id,
            author: user._id,
            content: (0, sanitize_1.sanitizeHtml)(req.body.content),
            parentComment: req.body.parentCommentId || null,
        });
        const populatedComment = await models_1.Comment.findById(comment._id)
            .populate('author', 'displayName username avatarUrl')
            .lean();
        logger_1.logger.info('Comment created:', { commentId: comment._id, postId: post._id });
        res.status(201).json(populatedComment);
    }
    catch (error) {
        next(error);
    }
});
/**
 * PUT /api/comments/:id
 * Update a comment (authenticated, author only)
 */
router.put('/comments/:id', auth_middleware_1.authenticate, [
    (0, express_validator_1.param)('id').isMongoId(),
    (0, express_validator_1.body)('content').isString().trim().isLength({ min: 1, max: 2000 }),
], handleValidation, async (req, res, next) => {
    try {
        const comment = await models_1.Comment.findById(req.params.id).populate('author', 'oid');
        if (!comment || comment.isDeleted) {
            next(error_middleware_1.ApiError.notFound('Comment'));
            return;
        }
        // Check ownership
        const authorOid = comment.author.oid;
        if (authorOid !== req.user.oid) {
            next(error_middleware_1.ApiError.forbidden('You can only edit your own comments'));
            return;
        }
        comment.content = (0, sanitize_1.sanitizeHtml)(req.body.content);
        comment.isEdited = true;
        await comment.save();
        const updatedComment = await models_1.Comment.findById(comment._id)
            .populate('author', 'displayName username avatarUrl')
            .lean();
        logger_1.logger.info('Comment updated:', { commentId: comment._id });
        res.json(updatedComment);
    }
    catch (error) {
        next(error);
    }
});
/**
 * DELETE /api/comments/:id
 * Delete a comment (authenticated, author only) - soft delete
 */
router.delete('/comments/:id', auth_middleware_1.authenticate, [(0, express_validator_1.param)('id').isMongoId()], handleValidation, async (req, res, next) => {
    try {
        const comment = await models_1.Comment.findById(req.params.id).populate('author', 'oid');
        if (!comment || comment.isDeleted) {
            next(error_middleware_1.ApiError.notFound('Comment'));
            return;
        }
        // Check ownership
        const authorOid = comment.author.oid;
        if (authorOid !== req.user.oid) {
            next(error_middleware_1.ApiError.forbidden('You can only delete your own comments'));
            return;
        }
        // Soft delete
        comment.isDeleted = true;
        comment.content = '[deleted]';
        await comment.save();
        logger_1.logger.info('Comment deleted:', { commentId: comment._id });
        res.status(204).send();
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=comments.routes.js.map