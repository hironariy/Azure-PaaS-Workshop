/**
 * Database Configuration
 * Cosmos DB for MongoDB vCore connection with Mongoose
 * Reference: /design/DatabaseDesign.md
 *
 * PaaS Changes from IaaS:
 * - Added retryWrites: false (Cosmos DB requirement)
 * - Added tls: true (Cosmos DB requirement) - only for production
 * - Supports both COSMOS_CONNECTION_STRING and MONGODB_URI env vars
 * - Auto-detects local vs production environment for TLS settings
 */
/**
 * Connect to Cosmos DB for MongoDB vCore or local MongoDB
 * Handles connection events and retries
 */
export declare function connectDatabase(): Promise<void>;
/**
 * Disconnect from database
 * Use during graceful shutdown
 */
export declare function disconnectDatabase(): Promise<void>;
/**
 * Check database connection health
 * Used by health check endpoint
 */
export declare function isDatabaseConnected(): boolean;
/**
 * Get database connection state as string
 */
export declare function getDatabaseState(): string;
//# sourceMappingURL=database.d.ts.map