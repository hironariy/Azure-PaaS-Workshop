"use strict";
/**
 * Database Configuration
 * Cosmos DB for MongoDB vCore connection with Mongoose
 * Reference: /design/DatabaseDesign.md
 *
 * PaaS Changes from IaaS:
 * - Added retryWrites: false (Cosmos DB requirement)
 * - Added tls: true (Cosmos DB requirement) - only for production
 * - Supports both COSMOS_CONNECTION_STRING and MONGODB_URI env vars
 * - Auto-detects local vs production environment for TLS settings
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDatabase = connectDatabase;
exports.disconnectDatabase = disconnectDatabase;
exports.isDatabaseConnected = isDatabaseConnected;
exports.getDatabaseState = getDatabaseState;
const mongoose_1 = __importDefault(require("mongoose"));
const environment_1 = require("./environment");
const logger_1 = require("../utils/logger");
/**
 * Detect if connecting to Cosmos DB (requires TLS) or local MongoDB (no TLS)
 */
function isCosmosDb(uri) {
    return uri.includes('cosmos.azure.com') || uri.includes('mongodb+srv://');
}
/**
 * Connect to Cosmos DB for MongoDB vCore or local MongoDB
 * Handles connection events and retries
 */
async function connectDatabase() {
    try {
        // Sanitize connection string for logging (hide credentials)
        const sanitizedUri = (0, logger_1.sanitizeConnectionString)(environment_1.config.databaseUri);
        logger_1.logger.info(`Connecting to database: ${sanitizedUri}`);
        const useCosmosDb = isCosmosDb(environment_1.config.databaseUri);
        // Mongoose connection options
        const options = {
            // Common options (same as IaaS)
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
            maxPoolSize: 10,
            minPoolSize: 2,
            // Connection management
            maxIdleTimeMS: 120000, // Close idle connections after 2 minutes
        };
        // Cosmos DB specific options (only for production)
        if (useCosmosDb) {
            options.retryWrites = false; // Cosmos DB doesn't support retry writes
            options.tls = true; // Cosmos DB requires TLS
            logger_1.logger.info('Using Cosmos DB connection settings (TLS enabled, retryWrites disabled)');
        }
        else {
            logger_1.logger.info('Using local MongoDB connection settings (TLS disabled)');
        }
        await mongoose_1.default.connect(environment_1.config.databaseUri, options);
        logger_1.logger.info(useCosmosDb
            ? '✅ Connected to Cosmos DB for MongoDB vCore'
            : '✅ Connected to local MongoDB');
        // Connection event handlers (same as IaaS)
        mongoose_1.default.connection.on('error', (err) => {
            logger_1.logger.error('Database connection error:', err);
        });
        mongoose_1.default.connection.on('disconnected', () => {
            logger_1.logger.warn('Database disconnected. Attempting to reconnect...');
        });
        mongoose_1.default.connection.on('reconnected', () => {
            logger_1.logger.info('Database reconnected');
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to connect to database:', error);
        throw error;
    }
}
/**
 * Disconnect from database
 * Use during graceful shutdown
 */
async function disconnectDatabase() {
    try {
        await mongoose_1.default.disconnect();
        logger_1.logger.info('Disconnected from database');
    }
    catch (error) {
        logger_1.logger.error('Error disconnecting from database:', error);
        throw error;
    }
}
/**
 * Check database connection health
 * Used by health check endpoint
 */
function isDatabaseConnected() {
    return mongoose_1.default.connection.readyState === 1;
}
/**
 * Get database connection state as string
 */
function getDatabaseState() {
    const states = {
        0: 'disconnected',
        1: 'connected',
        2: 'connecting',
        3: 'disconnecting',
    };
    return states[mongoose_1.default.connection.readyState] ?? 'unknown';
}
//# sourceMappingURL=database.js.map