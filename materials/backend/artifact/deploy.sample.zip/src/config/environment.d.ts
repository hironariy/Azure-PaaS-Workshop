/**
 * Environment Configuration
 * Loads and validates environment variables
 * Reference: /design/BackendApplicationDesign.md
 *
 * PaaS Changes from IaaS:
 * - Default port changed from 3000 to 8080 (App Service default)
 * - Added COSMOS_CONNECTION_STRING support alongside MONGODB_URI
 * - Rest of the configuration is identical to IaaS
 */
interface EnvironmentConfig {
    nodeEnv: string;
    port: number;
    databaseUri: string;
    entraTenantId: string;
    entraClientId: string;
    keyVaultName?: string;
    logLevel: string;
    corsOrigins: string[];
    rateLimitWindowMs: number;
    rateLimitMaxRequests: number;
}
export declare const config: EnvironmentConfig;
export declare const isProduction: () => boolean;
export declare const isDevelopment: () => boolean;
export {};
//# sourceMappingURL=environment.d.ts.map