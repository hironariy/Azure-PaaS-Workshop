"use strict";
/**
 * Environment Configuration
 * Loads and validates environment variables
 * Reference: /design/BackendApplicationDesign.md
 *
 * PaaS Changes from IaaS:
 * - Default port changed from 3000 to 8080 (App Service default)
 * - Added COSMOS_CONNECTION_STRING support alongside MONGODB_URI
 * - Rest of the configuration is identical to IaaS
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isDevelopment = exports.isProduction = exports.config = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Load .env file
dotenv_1.default.config({ path: path_1.default.resolve(__dirname, '../../.env') });
function getEnvVar(key, defaultValue) {
    const value = process.env[key] ?? defaultValue;
    if (value === undefined) {
        throw new Error(`Missing required environment variable: ${key}`);
    }
    return value;
}
function getEnvVarOptional(key) {
    return process.env[key];
}
function getEnvVarAsInt(key, defaultValue) {
    const value = process.env[key];
    if (value === undefined) {
        return defaultValue;
    }
    const parsed = parseInt(value, 10);
    if (isNaN(parsed)) {
        throw new Error(`Environment variable ${key} must be a number`);
    }
    return parsed;
}
/**
 * Get database connection string
 * Supports both PaaS (COSMOS_CONNECTION_STRING) and IaaS (MONGODB_URI) naming
 */
function getDatabaseUri() {
    // PaaS: Try COSMOS_CONNECTION_STRING first
    const cosmosUri = process.env.COSMOS_CONNECTION_STRING;
    if (cosmosUri) {
        return cosmosUri;
    }
    // IaaS: Fall back to MONGODB_URI
    const mongoUri = process.env.MONGODB_URI;
    if (mongoUri) {
        return mongoUri;
    }
    // Local development default
    return 'mongodb://localhost:27017/blogapp?directConnection=true';
}
exports.config = {
    nodeEnv: getEnvVar('NODE_ENV', 'development'),
    // PaaS change: App Service uses port 8080 by default
    port: getEnvVarAsInt('PORT', 8080),
    // PaaS change: Support both connection string names
    databaseUri: getDatabaseUri(),
    entraTenantId: getEnvVar('ENTRA_TENANT_ID', 'your-tenant-id'),
    entraClientId: getEnvVar('ENTRA_CLIENT_ID', 'your-client-id'),
    keyVaultName: getEnvVarOptional('KEY_VAULT_NAME'),
    logLevel: getEnvVar('LOG_LEVEL', 'debug'),
    corsOrigins: getEnvVar('CORS_ORIGINS', 'http://localhost:5173,http://localhost:3000').split(','),
    rateLimitWindowMs: getEnvVarAsInt('RATE_LIMIT_WINDOW_MS', 900000),
    rateLimitMaxRequests: getEnvVarAsInt('RATE_LIMIT_MAX_REQUESTS', 100),
};
const isProduction = () => exports.config.nodeEnv === 'production';
exports.isProduction = isProduction;
const isDevelopment = () => exports.config.nodeEnv === 'development';
exports.isDevelopment = isDevelopment;
//# sourceMappingURL=environment.js.map