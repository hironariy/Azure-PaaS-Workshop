/**
 * HTML sanitization utilities
 * Strips unsafe tags/attributes to mitigate stored XSS when rendering user content.
 *
 * No PaaS changes - identical to IaaS
 */
export declare function sanitizeHtml(input?: string | null): string;
export declare function sanitizePlain(input?: string | null): string;
export declare function sanitizeTagValue(value: string): string;
//# sourceMappingURL=sanitize.d.ts.map