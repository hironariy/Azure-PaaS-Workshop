"use strict";
/**
 * HTML sanitization utilities
 * Strips unsafe tags/attributes to mitigate stored XSS when rendering user content.
 *
 * No PaaS changes - identical to IaaS
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sanitizeHtml = sanitizeHtml;
exports.sanitizePlain = sanitizePlain;
exports.sanitizeTagValue = sanitizeTagValue;
const jsdom_1 = require("jsdom");
const dompurify_1 = __importDefault(require("dompurify"));
// Use a JSDOM window for server-side sanitization; cast to satisfy DOMPurify typings
const window = new jsdom_1.JSDOM('').window;
// @ts-expect-error JSDOM window implements the required DOMPurify Window shape at runtime
const DOMPurify = (0, dompurify_1.default)(window);
const DEFAULT_ALLOWED_TAGS = [
    'a', 'b', 'i', 'em', 'strong', 'p', 'ul', 'ol', 'li', 'br', 'span', 'code', 'pre',
];
const DEFAULT_ALLOWED_ATTR = ['href', 'title', 'rel', 'target'];
function sanitizeHtml(input) {
    if (!input)
        return '';
    return DOMPurify.sanitize(input, {
        ALLOWED_TAGS: DEFAULT_ALLOWED_TAGS,
        ALLOWED_ATTR: DEFAULT_ALLOWED_ATTR,
        RETURN_TRUSTED_TYPE: false,
    });
}
function sanitizePlain(input) {
    if (!input)
        return '';
    return sanitizeHtml(input).replace(/<[^>]+>/g, '');
}
function sanitizeTagValue(value) {
    return sanitizePlain(value).toLowerCase().trim();
}
//# sourceMappingURL=sanitize.js.map