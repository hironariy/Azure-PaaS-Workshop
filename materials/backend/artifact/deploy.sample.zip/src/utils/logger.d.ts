/**
 * Winston Logger Configuration
 * Structured JSON logging for production
 * Reference: /design/RepositoryWideDesignRules.md - Section 1.4 (Log Sanitization)
 *
 * PaaS Changes from IaaS:
 * - No changes required - App Service captures stdout/stderr automatically
 * - JSON format works with Log Analytics and Application Insights
 * - Same code as IaaS
 */
import winston from 'winston';
export declare const logger: winston.Logger;
/**
 * Sanitize sensitive data from logs
 * Reference: /design/RepositoryWideDesignRules.md - Section 1.4
 */
export declare function sanitizeForLog(data: Record<string, unknown>): Record<string, unknown>;
/**
 * Sanitize email for logging (u***@example.com)
 */
export declare function sanitizeEmail(email: string): string;
/**
 * Sanitize MongoDB/Cosmos DB connection string
 * Updated to handle both mongodb:// and mongodb+srv:// protocols
 */
export declare function sanitizeConnectionString(uri: string): string;
//# sourceMappingURL=logger.d.ts.map