/**
 * Error Handling Middleware
 * Centralized error handling for Express
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Custom API Error class
 */
export declare class ApiError extends Error {
    statusCode: number;
    code: string;
    details?: Record<string, unknown>;
    constructor(statusCode: number, message: string, code?: string, details?: Record<string, unknown>);
    static badRequest(message: string, details?: Record<string, unknown>): ApiError;
    static unauthorized(message?: string): ApiError;
    static forbidden(message?: string): ApiError;
    static notFound(resource?: string): ApiError;
    static conflict(message: string): ApiError;
    static internal(message?: string): ApiError;
}
/**
 * Global error handling middleware
 */
export declare function errorHandler(err: Error, _req: Request, res: Response, _next: NextFunction): void;
/**
 * 404 handler for unknown routes
 */
export declare function notFoundHandler(req: Request, _res: Response, next: NextFunction): void;
//# sourceMappingURL=error.middleware.d.ts.map