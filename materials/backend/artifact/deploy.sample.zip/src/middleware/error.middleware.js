"use strict";
/**
 * Error Handling Middleware
 * Centralized error handling for Express
 * Reference: /design/BackendApplicationDesign.md
 *
 * No PaaS changes - identical to IaaS
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiError = void 0;
exports.errorHandler = errorHandler;
exports.notFoundHandler = notFoundHandler;
const logger_1 = require("../utils/logger");
const environment_1 = require("../config/environment");
/**
 * Custom API Error class
 */
class ApiError extends Error {
    statusCode;
    code;
    details;
    constructor(statusCode, message, code = 'INTERNAL_ERROR', details) {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.details = details;
        this.name = 'ApiError';
    }
    static badRequest(message, details) {
        return new ApiError(400, message, 'BAD_REQUEST', details);
    }
    static unauthorized(message = 'Unauthorized') {
        return new ApiError(401, message, 'UNAUTHORIZED');
    }
    static forbidden(message = 'Forbidden') {
        return new ApiError(403, message, 'FORBIDDEN');
    }
    static notFound(resource = 'Resource') {
        return new ApiError(404, `${resource} not found`, 'NOT_FOUND');
    }
    static conflict(message) {
        return new ApiError(409, message, 'CONFLICT');
    }
    static internal(message = 'Internal server error') {
        return new ApiError(500, message, 'INTERNAL_ERROR');
    }
}
exports.ApiError = ApiError;
/**
 * Global error handling middleware
 */
function errorHandler(err, _req, res, _next) {
    // Log the error
    logger_1.logger.error('Error occurred:', {
        name: err.name,
        message: err.message,
        stack: err.stack,
    });
    // Determine status code and error details
    let statusCode = 500;
    let code = 'INTERNAL_ERROR';
    let message = 'Internal server error';
    let details;
    if (err instanceof ApiError) {
        statusCode = err.statusCode;
        code = err.code;
        message = err.message;
        details = err.details;
    }
    else if (err.name === 'ValidationError') {
        // Mongoose validation error
        statusCode = 400;
        code = 'VALIDATION_ERROR';
        message = err.message;
    }
    else if (err.name === 'CastError') {
        // Mongoose cast error (invalid ObjectId)
        statusCode = 400;
        code = 'INVALID_ID';
        message = 'Invalid resource ID format';
    }
    // Build response
    const response = {
        error: {
            code,
            message,
            details,
        },
    };
    // Include stack trace in development
    if (environment_1.config.nodeEnv === 'development') {
        response.error.stack = err.stack;
    }
    res.status(statusCode).json(response);
}
/**
 * 404 handler for unknown routes
 */
function notFoundHandler(req, _res, next) {
    next(ApiError.notFound(`Route ${req.method} ${req.path}`));
}
//# sourceMappingURL=error.middleware.js.map