"use strict";
/**
 * Authentication Middleware
 * JWT validation for Microsoft Entra ID tokens
 * Reference: /design/BackendApplicationDesign.md - Authentication section
 *
 * No PaaS changes - identical to IaaS
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
exports.optionalAuthenticate = optionalAuthenticate;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const jwks_rsa_1 = __importDefault(require("jwks-rsa"));
const environment_1 = require("../config/environment");
const logger_1 = require("../utils/logger");
const error_middleware_1 = require("./error.middleware");
// JWKS client for fetching Microsoft signing keys
const client = (0, jwks_rsa_1.default)({
    jwksUri: `https://login.microsoftonline.com/${environment_1.config.entraTenantId}/discovery/v2.0/keys`,
    cache: true,
    cacheMaxAge: 86400000, // 24 hours
    rateLimit: true,
    jwksRequestsPerMinute: 10,
});
/**
 * Get signing key from JWKS
 */
function getSigningKey(header) {
    return new Promise((resolve, reject) => {
        if (!header.kid) {
            reject(new Error('No kid in token header'));
            return;
        }
        client.getSigningKey(header.kid, (err, key) => {
            if (err) {
                reject(err);
                return;
            }
            if (!key) {
                reject(new Error('Signing key not found'));
                return;
            }
            const signingKey = key.getPublicKey();
            resolve(signingKey);
        });
    });
}
/**
 * Validate JWT token from Authorization header
 */
async function validateToken(token) {
    // Decode header to get kid
    const decoded = jsonwebtoken_1.default.decode(token, { complete: true });
    if (!decoded || typeof decoded === 'string') {
        throw new Error('Invalid token format');
    }
    // Get signing key
    const signingKey = await getSigningKey(decoded.header);
    // Verify token
    // Require the API resource URI as audience to avoid accepting SPA ID tokens
    // Accept both v1.0 (sts.windows.net) and v2.0 (login.microsoftonline.com/.../v2.0) issuers
    // to support different Entra ID app registration configurations
    const validIssuers = [
        `https://login.microsoftonline.com/${environment_1.config.entraTenantId}/v2.0`,
        `https://sts.windows.net/${environment_1.config.entraTenantId}/`,
    ];
    const payload = jsonwebtoken_1.default.verify(token, signingKey, {
        algorithms: ['RS256'],
        audience: `api://${environment_1.config.entraClientId}`,
        issuer: validIssuers,
    });
    // Extract user info from token
    // v1.0 tokens use 'upn' and 'unique_name', v2.0 uses 'preferred_username' and 'email'
    const email = payload.email
        ?? payload.preferred_username
        ?? payload.upn
        ?? payload.unique_name
        ?? '';
    return {
        oid: payload.oid,
        sub: payload.sub,
        name: payload.name ?? 'Unknown',
        email,
        preferredUsername: payload.preferred_username ?? payload.upn ?? '',
        roles: payload.roles,
    };
}
/**
 * Authentication middleware
 * Requires valid JWT in Authorization header
 */
async function authenticate(req, _res, next) {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader) {
            throw error_middleware_1.ApiError.unauthorized('No authorization header');
        }
        if (!authHeader.startsWith('Bearer ')) {
            throw error_middleware_1.ApiError.unauthorized('Invalid authorization format');
        }
        const token = authHeader.substring(7);
        if (!token) {
            throw error_middleware_1.ApiError.unauthorized('No token provided');
        }
        // Validate token and extract user
        const user = await validateToken(token);
        req.user = user;
        logger_1.logger.debug('User authenticated:', { oid: user.oid, name: user.name });
        next();
    }
    catch (error) {
        if (error instanceof error_middleware_1.ApiError) {
            next(error);
        }
        else if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
            next(error_middleware_1.ApiError.unauthorized('Token expired'));
        }
        else if (error instanceof jsonwebtoken_1.default.JsonWebTokenError) {
            next(error_middleware_1.ApiError.unauthorized('Invalid token'));
        }
        else {
            logger_1.logger.error('Authentication error:', error);
            next(error_middleware_1.ApiError.unauthorized('Authentication failed'));
        }
    }
}
/**
 * Optional authentication middleware
 * Attaches user if token is valid, continues without user if no token
 */
async function optionalAuthenticate(req, _res, next) {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            // No token - continue without user
            next();
            return;
        }
        const token = authHeader.substring(7);
        if (token) {
            const user = await validateToken(token);
            req.user = user;
        }
        next();
    }
    catch {
        // Token invalid - continue without user for optional authentication
        next();
    }
}
//# sourceMappingURL=auth.middleware.js.map