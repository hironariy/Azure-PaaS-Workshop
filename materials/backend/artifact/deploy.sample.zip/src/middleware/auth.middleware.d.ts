/**
 * Authentication Middleware
 * JWT validation for Microsoft Entra ID tokens
 * Reference: /design/BackendApplicationDesign.md - Authentication section
 *
 * No PaaS changes - identical to IaaS
 */
import { Request, Response, NextFunction } from 'express';
declare global {
    namespace Express {
        interface Request {
            user?: AuthenticatedUser;
        }
    }
}
/**
 * Authenticated user information extracted from JWT
 */
export interface AuthenticatedUser {
    oid: string;
    sub: string;
    name: string;
    email: string;
    preferredUsername: string;
    roles?: string[];
}
/**
 * Authentication middleware
 * Requires valid JWT in Authorization header
 */
export declare function authenticate(req: Request, _res: Response, next: NextFunction): Promise<void>;
/**
 * Optional authentication middleware
 * Attaches user if token is valid, continues without user if no token
 */
export declare function optionalAuthenticate(req: Request, _res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=auth.middleware.d.ts.map