/**
 * Seed Script
 * Populate Cosmos DB with sample data for development/testing
 *
 * Usage: npx ts-node scripts/seed.ts
 *
 * Reference: /design/DatabaseDesign.md
 *
 * PaaS Changes from IaaS:
 * - Connection string uses COSMOS_CONNECTION_STRING or MONGODB_URI
 * - Same data model, same Mongoose code
 */
export {};
//# sourceMappingURL=seed.d.ts.map